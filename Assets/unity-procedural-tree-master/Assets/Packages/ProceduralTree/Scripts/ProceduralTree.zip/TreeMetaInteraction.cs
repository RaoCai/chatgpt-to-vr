using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace ProceduralModeling {

    [RequireComponent(typeof(ProceduralTree))]
    public class TreeMetaInteraction : MonoBehaviour {
        public GameObject branchUIPrefab;
        public Canvas uiCanvas;

        private ProceduralTree proceduralTree;
        private Dictionary<int, GameObject> branchUIs = new Dictionary<int, GameObject>();

        void Start() {
            proceduralTree = GetComponent<ProceduralTree>();
            CreateBranchUIs();
        }

        void CreateBranchUIs() {
            foreach (var branchPosition in proceduralTree.BranchPositions) {
                CreateBranchUI(branchPosition.Key, branchPosition.Value);
            }
        }

        void CreateBranchUI(int branchId, Vector3 position) {
            GameObject branchUI = Instantiate(branchUIPrefab, uiCanvas.transform);
            branchUI.GetComponent<RectTransform>().anchoredPosition = Camera.main.WorldToScreenPoint(position);

            Button deleteButton = branchUI.GetComponentInChildren<Button>();
            deleteButton.onClick.AddListener(() => DeleteBranch(branchId));

            branchUIs[branchId] = branchUI;
        }

        void DeleteBranch(int branchId) {
            Debug.Log($"Deleting branch {branchId}");

            if (branchUIs.TryGetValue(branchId, out GameObject branchUI)) {
                Destroy(branchUI);
                branchUIs.Remove(branchId);
            }

            proceduralTree.DeleteBranch(branchId);

            foreach (var ui in branchUIs.Values) {
                Destroy(ui);
            }
            branchUIs.Clear();

            proceduralTree.Rebuild();

            CreateBranchUIs();
        }

        void Update() {
            // Update UI positions if the camera moves
            foreach (var branchUI in branchUIs) {
                Vector3 screenPos = Camera.main.WorldToScreenPoint(proceduralTree.BranchPositions[branchUI.Key]);
                branchUI.Value.GetComponent<RectTransform>().anchoredPosition = screenPos;
            }
        }
    }
}